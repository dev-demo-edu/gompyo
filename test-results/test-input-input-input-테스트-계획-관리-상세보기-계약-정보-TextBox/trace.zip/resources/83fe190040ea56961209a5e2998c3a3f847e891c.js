(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/bda13_react-apexcharts_dist_react-apexcharts_min_861cac3b.js", {

"[project]/node_modules/.pnpm/react-apexcharts@1.7.0_apexcharts@4.5.0_react@19.0.0/node_modules/react-apexcharts/dist/react-apexcharts.min.js [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules__pnpm_c942f87e._.js",
  "static/chunks/bda13_react-apexcharts_dist_react-apexcharts_min_ea1d9852.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/.pnpm/react-apexcharts@1.7.0_apexcharts@4.5.0_react@19.0.0/node_modules/react-apexcharts/dist/react-apexcharts.min.js [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);