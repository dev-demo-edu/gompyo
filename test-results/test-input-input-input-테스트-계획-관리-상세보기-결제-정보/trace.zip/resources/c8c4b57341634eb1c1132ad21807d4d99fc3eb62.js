(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_6501415d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_6501415d._.js",
  "chunks": [
    "static/chunks/bda13_react-apexcharts_dist_react-apexcharts_min_861cac3b.js",
    "static/chunks/node_modules__pnpm_9de896a6._.js",
    "static/chunks/src_927e6ba9._.js"
  ],
  "source": "dynamic"
});
