(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_e69f0d32._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_e69f0d32._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_09cf7c02._.js",
    "static/chunks/b4b3c_next_dist_compiled_fe745776._.js",
    "static/chunks/b4b3c_next_dist_client_a6e70ad0._.js",
    "static/chunks/b4b3c_next_dist_aa4917aa._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
  ],
  "source": "entry"
});
