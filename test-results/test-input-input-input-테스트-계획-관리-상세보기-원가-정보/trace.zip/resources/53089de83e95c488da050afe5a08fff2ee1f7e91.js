(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_login_page_tsx_6501415d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_login_page_tsx_6501415d._.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_ec075a6a._.js",
    "static/chunks/src_bf9fb245._.js"
  ],
  "source": "dynamic"
});
