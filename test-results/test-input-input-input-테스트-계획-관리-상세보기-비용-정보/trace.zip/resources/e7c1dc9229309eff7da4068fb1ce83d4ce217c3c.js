(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/bda13_react-apexcharts_dist_react-apexcharts_min_ea1d9852.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/bda13_react-apexcharts_dist_react-apexcharts_min_ea1d9852.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_c942f87e._.js"
  ],
  "source": "dynamic"
});
