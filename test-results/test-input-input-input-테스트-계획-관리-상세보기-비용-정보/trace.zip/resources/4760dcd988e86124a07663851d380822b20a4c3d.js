(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_plan_page_tsx_6501415d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_plan_page_tsx_6501415d._.js",
  "chunks": [
    "static/chunks/src_c2ca990b._.js",
    "static/chunks/cde14_ag-grid-community_dist_package_main_esm_mjs_0ec82778._.js",
    "static/chunks/be240_ag-grid-react_dist_package_index_esm_mjs_b049878f._.js",
    "static/chunks/00efe_@ag-grid-community_locale_dist_package_main_esm_mjs_e852e333._.js",
    "static/chunks/c95a8_@mui_material_e52cbeb4._.js",
    "static/chunks/05b4d_zod_lib_index_mjs_b32e4c10._.js",
    "static/chunks/node_modules__pnpm_8f868aa2._.js"
  ],
  "source": "dynamic"
});
