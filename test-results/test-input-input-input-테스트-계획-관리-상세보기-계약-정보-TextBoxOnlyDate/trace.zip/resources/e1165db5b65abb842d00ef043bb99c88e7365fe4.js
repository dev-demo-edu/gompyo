(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_d070c4f9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_d070c4f9._.js",
  "chunks": [
    "static/chunks/[root of the server]__8f7d2e9b._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_19d09cf5._.js",
    "static/chunks/b4b3c_next_b30ccffa._.js",
    "static/chunks/f1f13_@mui_system_esm_94bbb96c._.js",
    "static/chunks/c95a8_@mui_material_5ca665db._.js",
    "static/chunks/9b63b_@mui_base_32330787._.js",
    "static/chunks/23d63_@popperjs_core_lib_d220352c._.js",
    "static/chunks/node_modules__pnpm_ac3ffd60._.js",
    "static/chunks/src_db8cf4a4._.js"
  ],
  "source": "dynamic"
});
