(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_favicon_ico_mjs_4a87a049._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_favicon_ico_mjs_4a87a049._.js",
  "chunks": [
    "static/chunks/b4b3c_next_dist_88377c36._.js"
  ],
  "source": "dynamic"
});
